import React from 'react';
import { EditorProvider } from './context/EditorContext';
import { HistoryProvider } from './context/HistoryContext';
import { SelectionProvider } from './context/SelectionContext';
import { SnapProvider } from './context/SnapContext';
import EditorShell from './EditorShell';

function App() {
    return (
        <HistoryProvider>
            <EditorProvider>
                <SelectionProvider>
                    <SnapProvider>
                        <EditorShell />
                    </SnapProvider>
                </SelectionProvider>
            </EditorProvider>
        </HistoryProvider>
    );
}

export default App;
