import React, { forwardRef } from 'react';
import ElabPage from './ElabPage';
import BlockRenderer from '../blocks/BlockRenderer';

const VolumePreview = forwardRef(({ pages }, ref) => {
    return (
        <div ref={ref} className="print-container">
            {pages.map((page) => (
                <div key={page.id} className="print-page-break">
                    <ElabPage backgroundPattern={page.backgroundPattern}>
                        {page.blocks.map(block => (
                            <div key={block.id} className="mb-4">
                                <BlockRenderer block={block} />
                            </div>
                        ))}
                    </ElabPage>
                </div>
            ))}
        </div>
    );
});

export default VolumePreview;
