// Export all PCB decoration components
export { default as PCBHeader } from './PCBHeader';
export { default as PCBFooter } from './PCBFooter';
export { default as PCBCorner } from './PCBCorner';
export { default as PCBBackground } from './PCBBackground';
export { default as ChapterBadge } from './ChapterBadge';
