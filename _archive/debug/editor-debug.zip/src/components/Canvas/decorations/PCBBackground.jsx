import React from 'react';

/**
 * PCBBackground - Subtle PCB pattern background
 * Very light overlay for the entire page, inspired by Volume 1
 */
const PCBBackground = ({ opacity = 0.08, tint = 'none' }) => {
    const tints = {
        none: 'transparent',
        green: 'rgba(124, 179, 66, 0.03)',
        blue: 'rgba(27, 49, 94, 0.03)',
        orange: 'rgba(245, 158, 11, 0.03)'
    };

    return (
        <div className="absolute inset-0 pointer-events-none z-0">
            {/* Tint layer */}
            {tint !== 'none' && (
                <div
                    className="absolute inset-0"
                    style={{ backgroundColor: tints[tint] }}
                />
            )}

            {/* PCB pattern */}
            <div
                className="absolute inset-0"
                style={{
                    backgroundImage: 'url(/assets/bg-pcb.jpg)',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    backgroundRepeat: 'no-repeat',
                    opacity: opacity,
                    mixBlendMode: 'multiply'
                }}
            />
        </div>
    );
};

export default PCBBackground;
