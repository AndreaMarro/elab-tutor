import React from 'react';

/**
 * PCBCorner - Decorative corner element with PCB pattern
 * Inspired by Volume 1 design with angled green corner
 */
const PCBCorner = ({
    variant = 'green',
    position = 'top-left',
    size = '200px'
}) => {
    const colors = {
        green: {
            solid: '#7CB342',
            gradient: 'linear-gradient(135deg, #7CB342 0%, #8BC34A 100%)',
        },
        orange: {
            solid: '#F59E0B',
            gradient: 'linear-gradient(135deg, #F59E0B 0%, #FB923C 100%)',
        },
        blue: {
            solid: '#1B315E',
            gradient: 'linear-gradient(135deg, #1B315E 0%, #2563EB 100%)',
        }
    };

    const selectedColor = colors[variant] || colors.green;

    // Position classes
    const positionClasses = {
        'top-left': 'top-0 left-0',
        'top-right': 'top-0 right-0',
        'bottom-left': 'bottom-0 left-0',
        'bottom-right': 'bottom-0 right-0'
    };

    // Rotation for different positions
    const rotations = {
        'top-left': '0deg',
        'top-right': '90deg',
        'bottom-left': '-90deg',
        'bottom-right': '180deg'
    };

    return (
        <div
            className={`absolute ${positionClasses[position]} overflow-hidden pointer-events-none`}
            style={{
                width: size,
                height: size,
                transform: `rotate(${rotations[position]})`
            }}
        >
            {/* Triangular shape */}
            <div
                className="absolute inset-0"
                style={{
                    clipPath: 'polygon(0 0, 100% 0, 0 100%)',
                    background: selectedColor.gradient,
                    opacity: 0.9
                }}
            />

            {/* PCB pattern overlay */}
            <div
                className="absolute inset-0 opacity-40"
                style={{
                    clipPath: 'polygon(0 0, 100% 0, 0 100%)',
                    backgroundImage: 'url(/assets/bg-pcb.jpg)',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    mixBlendMode: 'overlay'
                }}
            />

            {/* Subtle edge highlight */}
            <div
                className="absolute inset-0"
                style={{
                    clipPath: 'polygon(0 0, 100% 0, 0 100%)',
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 50%)'
                }}
            />
        </div>
    );
};

export default PCBCorner;
