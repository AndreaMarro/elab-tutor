import React from 'react';

/**
 * ChapterBadge - "CAPITOLO X" badge component
 * Inspired by Volume 1 design - appears in top right corner
 */
const ChapterBadge = ({
    chapterNumber = 1,
    variant = 'green',
    position = 'top-right'
}) => {
    const colors = {
        green: {
            bg: '#7CB342',
            text: '#FFFFFF',
            border: '#689F38'
        },
        orange: {
            bg: '#F59E0B',
            text: '#FFFFFF',
            border: '#D97706'
        },
        blue: {
            bg: '#1B315E',
            text: '#FFFFFF',
            border: '#1E40AF'
        }
    };

    const selectedColor = colors[variant] || colors.green;

    const positionClasses = {
        'top-right': 'top-4 right-4',
        'top-left': 'top-4 left-4',
        'top-center': 'top-4 left-1/2 -translate-x-1/2'
    };

    return (
        <div
            className={`absolute ${positionClasses[position]} z-20`}
        >
            <div
                className="px-6 py-2 rounded-md shadow-lg"
                style={{
                    backgroundColor: selectedColor.bg,
                    borderBottom: `3px solid ${selectedColor.border}`,
                }}
            >
                <span
                    className="text-sm font-bold tracking-wider uppercase"
                    style={{
                        color: selectedColor.text,
                        fontFamily: 'system-ui, -apple-system, sans-serif',
                        letterSpacing: '0.1em'
                    }}
                >
                    CAPITOLO {chapterNumber}
                </span>
            </div>
        </div>
    );
};

export default ChapterBadge;
