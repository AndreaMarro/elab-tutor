import React from 'react';

/**
 * PCBFooter - Decorative footer with PCB pattern
 * Inspired by Volume 1 design with blue accent strip and page number
 */
const PCBFooter = ({ variant = 'blue', height = '50px', pageNumber, title }) => {
    const colors = {
        blue: {
            solid: '#1B315E',
            gradient: 'linear-gradient(90deg, #1B315E 0%, #2563EB 100%)',
        },
        orange: {
            solid: '#F59E0B',
            gradient: 'linear-gradient(90deg, #F59E0B 0%, #FB923C 100%)',
        },
        green: {
            solid: '#7CB342',
            gradient: 'linear-gradient(90deg, #7CB342 0%, #8BC34A 100%)',
        }
    };

    const selectedColor = colors[variant] || colors.blue;

    return (
        <div
            className="relative w-full overflow-hidden"
            style={{ height }}
        >
            {/* Solid color strip */}
            <div
                className="absolute inset-0"
                style={{
                    background: selectedColor.gradient,
                    opacity: 0.95
                }}
            />

            {/* PCB pattern overlay */}
            <div
                className="absolute inset-0 opacity-30"
                style={{
                    backgroundImage: 'url(/assets/bg-pcb.jpg)',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    mixBlendMode: 'overlay'
                }}
            />

            {/* Content layer */}
            <div className="absolute inset-0 flex items-center justify-between px-6 text-white">
                {/* Title on the left */}
                {title && (
                    <span className="text-sm font-medium tracking-wide">
                        {title}
                    </span>
                )}

                {/* Page number on the right */}
                {pageNumber && (
                    <span className="text-2xl font-bold">
                        {pageNumber}
                    </span>
                )}
            </div>

            {/* Subtle top shadow */}
            <div
                className="absolute top-0 left-0 right-0 h-1"
                style={{
                    background: 'linear-gradient(to top, transparent, rgba(0,0,0,0.1))'
                }}
            />
        </div>
    );
};

export default PCBFooter;
