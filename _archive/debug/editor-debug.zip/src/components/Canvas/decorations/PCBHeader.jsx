import React from 'react';

/**
 * PCBHeader - Decorative header with PCB pattern
 * Inspired by Volume 1 design with orange accent strip
 */
const PCBHeader = ({ variant = 'orange', height = '40px' }) => {
    const colors = {
        orange: {
            solid: '#F59E0B',
            gradient: 'linear-gradient(90deg, #F59E0B 0%, #FB923C 100%)',
        },
        blue: {
            solid: '#1B315E',
            gradient: 'linear-gradient(90deg, #1B315E 0%, #2563EB 100%)',
        },
        green: {
            solid: '#7CB342',
            gradient: 'linear-gradient(90deg, #7CB342 0%, #8BC34A 100%)',
        }
    };

    const selectedColor = colors[variant] || colors.orange;

    return (
        <div
            className="relative w-full overflow-hidden"
            style={{ height }}
        >
            {/* Solid color strip */}
            <div
                className="absolute inset-0"
                style={{
                    background: selectedColor.gradient,
                    opacity: 0.95
                }}
            />

            {/* PCB pattern overlay */}
            <div
                className="absolute inset-0 opacity-30"
                style={{
                    backgroundImage: 'url(/assets/bg-pcb.jpg)',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    mixBlendMode: 'overlay'
                }}
            />

            {/* Subtle bottom shadow */}
            <div
                className="absolute bottom-0 left-0 right-0 h-1"
                style={{
                    background: 'linear-gradient(to bottom, transparent, rgba(0,0,0,0.1))'
                }}
            />
        </div>
    );
};

export default PCBHeader;
