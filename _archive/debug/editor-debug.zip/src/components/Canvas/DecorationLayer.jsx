import React, { useRef } from 'react';
import { useEditor } from '../../context/EditorContext';
import TraceStraight from '../decorations/traces/TraceStraight';
import TraceCorner from '../decorations/traces/TraceCorner';
import TraceT from '../decorations/traces/TraceT';
import TraceEndPad from '../decorations/traces/TraceEndPad';
import { Trash2, RotateCw } from 'lucide-react';

const DecorationLayer = () => {
    const {
        activePageDecorations,
        updateDecoration,
        removeDecoration,
        selectedDecorationId,
        setSelectedDecorationId
    } = useEditor();


    // Deselect when clicking outside (handled by parent or overlay, but here we stop propagation on click)
    const handleDecorationClick = (e, id) => {
        e.stopPropagation();
        setSelectedDecorationId(id);
    };

    const renderDecoration = (decoration) => {
        const commonProps = {
            className: "w-full h-full",
            color: decoration.color,
            opacity: decoration.opacity
        };

        switch (decoration.type) {
            case 'trace-straight': return <TraceStraight {...commonProps} />;
            case 'trace-corner': return <TraceCorner {...commonProps} />;
            case 'trace-t': return <TraceT {...commonProps} />;
            case 'trace-end-pad': return <TraceEndPad {...commonProps} />;
            default: return null;
        }
    };

    return (
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
            {(activePageDecorations || []).map(decoration => (
                <DraggableDecoration
                    key={decoration.id}
                    decoration={decoration}
                    isSelected={selectedDecorationId === decoration.id}
                    onSelect={(e) => handleDecorationClick(e, decoration.id)}
                    onUpdate={(newData) => updateDecoration(decoration.id, newData)}
                    onRemove={() => removeDecoration(decoration.id)}
                >
                    {renderDecoration(decoration)}
                </DraggableDecoration>
            ))}
        </div>
    );
};

const DraggableDecoration = ({ decoration, isSelected, onSelect, onUpdate, onRemove, children }) => {
    const isDragging = useRef(false);
    const startPos = useRef({ x: 0, y: 0 });
    const initialPos = useRef({ x: 0, y: 0 });

    const handleMouseDown = (e) => {
        if (e.button !== 0) return; // Only left click
        e.stopPropagation();
        onSelect(e);

        isDragging.current = true;
        startPos.current = { x: e.clientX, y: e.clientY };
        initialPos.current = { x: decoration.x, y: decoration.y };

        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    };

    const handleMouseMove = (e) => {
        if (!isDragging.current) return;

        const dx = e.clientX - startPos.current.x;
        const dy = e.clientY - startPos.current.y;

        // Convert screen delta to mm (approximate, assuming 1px = 1px in CSS for now, but zoom might affect this)
        // Since the canvas is fixed size in CSS pixels, 1-1 mapping usually works if no zoom.
        // If zoom is implemented, we'd need to divide by scale. Assuming scale=1 for now.

        onUpdate({
            x: initialPos.current.x + dx,
            y: initialPos.current.y + dy
        });
    };

    const handleMouseUp = () => {
        isDragging.current = false;
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
    };

    const handleRotate = (e) => {
        e.stopPropagation();
        const newRotation = (decoration.rotation + 90) % 360;
        onUpdate({ rotation: newRotation });
    };

    return (
        <div
            className={`absolute pointer-events-auto group ${isSelected ? 'z-50' : 'z-10'}`}
            style={{
                left: decoration.x,
                top: decoration.y,
                width: decoration.width,
                height: decoration.height,
                transform: `rotate(${decoration.rotation}deg)`,
                cursor: isSelected ? 'move' : 'pointer'
            }}
            onMouseDown={handleMouseDown}
        >
            {/* Render Content */}
            <div className={`w-full h-full ${isSelected ? 'ring-2 ring-blue-500 ring-offset-2' : 'hover:ring-1 hover:ring-blue-300'}`}>
                {children}
            </div>

            {/* Controls (Visible only when selected) */}
            {isSelected && (
                <>
                    {/* Rotate Handle */}
                    <div
                        className="absolute -top-8 left-1/2 -translate-x-1/2 bg-white rounded-full p-1 shadow-md cursor-pointer hover:bg-blue-50 border border-gray-200"
                        onMouseDown={(e) => e.stopPropagation()}
                        onClick={handleRotate}
                        title="Ruota 90°"
                    >
                        <RotateCw size={16} className="text-blue-600" />
                    </div>

                    {/* Delete Handle */}
                    <div
                        className="absolute -top-8 -right-8 bg-white rounded-full p-1 shadow-md cursor-pointer hover:bg-red-50 border border-gray-200"
                        onMouseDown={(e) => e.stopPropagation()}
                        onClick={(e) => { e.stopPropagation(); onRemove(); }}
                        title="Elimina"
                    >
                        <Trash2 size={16} className="text-red-600" />
                    </div>

                    {/* Resize Handle (Simple bottom-right corner) */}
                    <div
                        className="absolute -bottom-2 -right-2 w-4 h-4 bg-blue-500 rounded-full cursor-se-resize border-2 border-white shadow"
                        onMouseDown={(e) => {
                            e.stopPropagation();
                            const startX = e.clientX;
                            const startY = e.clientY;
                            const startW = decoration.width;
                            const startH = decoration.height;

                            const handleResizeMove = (moveEvent) => {
                                const w = startW + (moveEvent.clientX - startX);
                                const h = startH + (moveEvent.clientY - startY);
                                onUpdate({ width: Math.max(20, w), height: Math.max(20, h) });
                            };

                            const handleResizeUp = () => {
                                document.removeEventListener('mousemove', handleResizeMove);
                                document.removeEventListener('mouseup', handleResizeUp);
                            };

                            document.addEventListener('mousemove', handleResizeMove);
                            document.addEventListener('mouseup', handleResizeUp);
                        }}
                    />
                </>
            )}
        </div>
    );
};

export default DecorationLayer;
