import React, { forwardRef } from 'react';
import PCBBanner from '../page/PCBBanner';
import PageHeader from '../page/PageHeader';

/**
 * ElabPage - Pagina ELAB autentica basata sul libro reale
 * 
 * STRUTTURA DAL LIBRO:
 * ┌─────────────────────────────────────┐
 * │  ╔═══════════════════╗              │  ← Banner PCB trapezoidale (opzionale)
 * │  ║   PCB TRACES      ╲              │     lime #A8D853
 * │  ╚═════════════════════╝            │
 * │                                     │
 * │  🤖              TITOLO SEZIONE ─── │  ← Header con robot (opzionale)
 * │                                     │
 * │         CONTENUTO BLOCCHI           │
 * │                                     │
 * │ ┌─────────────────────────────────┐ │
 * │ │ 6  Laboratorio di elettronica  │ │  ← Footer navy SEMPRE presente
 * │ └─────────────────────────────────┘ │
 * └─────────────────────────────────────┘
 * 
 * COLORI ELAB AUTENTICI:
 * - Navy: #1B315E
 * - Lime: #A8D853
 * - Ciano: #4AA5A5
 * - Mint: #E8F5E9
 */

const ELAB_COLORS = {
  navy: '#1B315E',
  lime: '#A8D853',
  cyan: '#4AA5A5',
  mint: '#E8F5E9',
  white: '#FFFFFF',
  text: '#374151',
};

const ElabPage = forwardRef(({ 
  children, 
  backgroundPattern = 'white',
  pageNumber = 1,
  bookTitle = 'Laboratorio di elettronica: Impara e sperimenta',
  sectionTitle = '',
  chapterLabel = '',
  showPCBBanner = false,
  showHeader = false,
  showFooter = true,
  variant = 'content', // 'content' | 'chapter' | 'notes'
}, ref) => {

  // Sfondo in base al pattern
  const getBackgroundStyle = () => {
    switch (backgroundPattern) {
      case 'grid':
        return {
          backgroundImage: 'radial-gradient(circle, #CBD5E1 1.5px, transparent 1.5px)',
          backgroundSize: '24px 24px',
          backgroundColor: '#FAFAFA'
        };
      case 'tech':
        return {
          backgroundImage: `
            radial-gradient(circle, rgba(27, 49, 94, 0.04) 1px, transparent 1px),
            radial-gradient(circle, rgba(27, 49, 94, 0.02) 1px, transparent 1px)
          `,
          backgroundSize: '20px 20px, 40px 40px',
          backgroundColor: '#F9FAFB',
          backgroundPosition: '0 0, 10px 10px'
        };
      default:
        return { backgroundColor: ELAB_COLORS.white };
    }
  };

  // Pagina NOTE speciale
  if (variant === 'notes') {
    return (
      <div
        ref={ref}
        className="elab-page print-container relative shadow-2xl mx-auto overflow-hidden flex flex-col"
        style={{
          width: '210mm',
          height: '297mm',
          backgroundColor: ELAB_COLORS.white,
        }}
      >
        {/* Banner PCB grande per pagina note */}
        <PCBBanner height={140} variant="top" />
        
        {/* Spazio */}
        <div style={{ height: '30px' }} />
        
        {/* Box NOTE con sfondo lime */}
        <div 
          style={{
            margin: '0 20mm',
            flex: 1,
            backgroundColor: ELAB_COLORS.lime,
            borderRadius: '8px',
            padding: '16px',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          {/* Box bianco interno */}
          <div 
            style={{
              backgroundColor: ELAB_COLORS.white,
              border: `3px solid ${ELAB_COLORS.lime}`,
              borderRadius: '4px',
              flex: 1,
              padding: '20px',
            }}
          >
            {/* Label NOTE */}
            <div 
              style={{
                fontFamily: "'Oswald', sans-serif",
                fontSize: '16px',
                fontWeight: 700,
                color: ELAB_COLORS.navy,
                textTransform: 'uppercase',
                letterSpacing: '0.1em',
                marginBottom: '16px',
              }}
            >
              NOTE
            </div>
            
            {/* Righe per scrivere */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
              {Array.from({ length: 12 }).map((_, i) => (
                <div 
                  key={i}
                  style={{
                    borderBottom: '1px solid #CBD5E1',
                    height: '1px',
                  }}
                />
              ))}
            </div>
          </div>
        </div>
        
        {/* Footer */}
        {showFooter && (
          <div 
            style={{
              backgroundColor: ELAB_COLORS.navy,
              height: '45px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: pageNumber % 2 === 0 ? 'flex-start' : 'flex-end',
              padding: '0 20mm',
              marginTop: '20px',
            }}
          >
            {pageNumber % 2 === 0 ? (
              <>
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontWeight: 700,
                  fontSize: '16px',
                  color: ELAB_COLORS.white,
                  marginRight: '20px',
                }}>
                  {pageNumber}
                </span>
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontStyle: 'italic',
                  fontSize: '12px',
                  color: ELAB_COLORS.white,
                }}>
                  {bookTitle}
                </span>
              </>
            ) : (
              <>
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontStyle: 'italic',
                  fontSize: '12px',
                  color: ELAB_COLORS.white,
                  marginRight: '20px',
                }}>
                  {bookTitle}
                </span>
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontWeight: 700,
                  fontSize: '16px',
                  color: ELAB_COLORS.white,
                }}>
                  {pageNumber}
                </span>
              </>
            )}
          </div>
        )}
      </div>
    );
  }

  // Pagina CHAPTER (inizio capitolo)
  if (variant === 'chapter') {
    return (
      <div
        ref={ref}
        className="elab-page print-container relative shadow-2xl mx-auto overflow-hidden flex flex-col"
        style={{
          width: '210mm',
          height: '297mm',
          ...getBackgroundStyle(),
        }}
      >
        {/* Banner PCB per inizio capitolo */}
        {showPCBBanner && <PCBBanner height={120} variant="top" />}
        
        {/* Header capitolo */}
        <div style={{ padding: '30mm 20mm 0 20mm' }}>
          <PageHeader 
            title={sectionTitle}
            chapterLabel={chapterLabel}
            variant="chapter"
            showRobot={false}
          />
        </div>
        
        {/* Contenuto */}
        <main 
          className="flex-grow overflow-auto"
          style={{ 
            padding: '20px 20mm',
            display: 'flex',
            flexDirection: 'column',
            gap: '24px',
          }}
        >
          {children}
        </main>
        
        {/* Footer navy */}
        {showFooter && (
          <div 
            style={{
              backgroundColor: ELAB_COLORS.navy,
              height: '45px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: pageNumber % 2 === 0 ? 'flex-start' : 'flex-end',
              padding: '0 20mm',
            }}
          >
            {pageNumber % 2 === 0 ? (
              <>
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontWeight: 700,
                  fontSize: '16px',
                  color: ELAB_COLORS.white,
                  marginRight: '20px',
                }}>
                  {pageNumber}
                </span>
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontStyle: 'italic',
                  fontSize: '12px',
                  color: ELAB_COLORS.white,
                }}>
                  {bookTitle}
                </span>
              </>
            ) : (
              <>
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontStyle: 'italic',
                  fontSize: '12px',
                  color: ELAB_COLORS.white,
                  marginRight: '20px',
                }}>
                  {bookTitle}
                </span>
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontWeight: 700,
                  fontSize: '16px',
                  color: ELAB_COLORS.white,
                }}>
                  {pageNumber}
                </span>
              </>
            )}
          </div>
        )}
      </div>
    );
  }

  // Pagina CONTENT normale (default)
  return (
    <div
      ref={ref}
      className="elab-page print-container relative shadow-2xl mx-auto overflow-hidden flex flex-col"
      style={{
        width: '210mm',
        height: '297mm',
        ...getBackgroundStyle(),
      }}
    >
      {/* Banner PCB opzionale */}
      {showPCBBanner && <PCBBanner height={100} variant="top" />}
      
      {/* Header con robot + titolo sezione */}
      {showHeader && sectionTitle && (
        <div style={{ padding: '15mm 20mm 0 20mm' }}>
          <PageHeader 
            title={sectionTitle}
            variant="section"
            showRobot={true}
          />
        </div>
      )}
      
      {/* Bleed guides (solo editor) */}
      <div className="absolute inset-0 pointer-events-none z-50 no-print">
        <div className="absolute top-[3mm] left-[3mm] right-[3mm] bottom-[3mm] border border-cyan-500/30 border-dashed"></div>
      </div>
      
      {/* Area contenuto blocchi */}
      <main 
        className="flex-grow overflow-auto z-10"
        style={{ 
          padding: showPCBBanner ? '10px 20mm 20px' : '20mm 20mm 20px',
          paddingBottom: showFooter ? '60px' : '20px',
          display: 'flex',
          flexDirection: 'column',
          gap: '24px',
        }}
      >
        {children}
      </main>
      
      {/* Footer navy SEMPRE presente */}
      {showFooter && (
        <div 
          className="absolute bottom-0 left-0 right-0"
          style={{
            backgroundColor: ELAB_COLORS.navy,
            height: '45px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0 20mm',
          }}
        >
          {pageNumber % 2 === 0 ? (
            // Pagina PARI: numero a sinistra
            <>
              <span style={{
                fontFamily: "'Oswald', sans-serif",
                fontWeight: 700,
                fontSize: '16px',
                color: ELAB_COLORS.white,
              }}>
                {pageNumber}
              </span>
              <span style={{
                fontFamily: "'Oswald', sans-serif",
                fontStyle: 'italic',
                fontSize: '12px',
                color: ELAB_COLORS.white,
                letterSpacing: '0.02em',
              }}>
                {bookTitle}
              </span>
            </>
          ) : (
            // Pagina DISPARI: numero a destra
            <>
              <span style={{
                fontFamily: "'Oswald', sans-serif",
                fontStyle: 'italic',
                fontSize: '12px',
                color: ELAB_COLORS.white,
                letterSpacing: '0.02em',
              }}>
                {bookTitle}
              </span>
              <span style={{
                fontFamily: "'Oswald', sans-serif",
                fontWeight: 700,
                fontSize: '16px',
                color: ELAB_COLORS.white,
              }}>
                {pageNumber}
              </span>
            </>
          )}
        </div>
      )}
    </div>
  );
});

ElabPage.displayName = 'ElabPage';

export default ElabPage;
